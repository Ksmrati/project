
<br>
Dear {{$donate['name']}},
<br>
Thank you! We obliged to your valuable contribution.

<br>
Best Regards
<br>
Demolaravel

