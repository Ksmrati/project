

<?php

$MERCHANT_KEY = "7km59b6n";
$SALT = "c9GIxx4k19";
$surl = "https://www.consumer-voice.org/donate-success/";
$furl = "https://www.consumer-voice.org/payumoney-failure/";
$productInfo    = "Donate";

// Merchant Key and Salt as provided by Payu.

//$PAYU_BASE_URL = "https://sandboxsecure.payu.in";     // For Sandbox Mode
$PAYU_BASE_URL = "https://secure.payu.in";          // For Production Mode

$action = '';

$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
    
  }
}

$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
          || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
    $hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';  
    foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>
<html>
  <head>
  <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>
 
  </head>

  <body onload="submitPayuForm()">
  
    <br/>
    <?php if($formError) { ?>
    
      <span style="color:red">Please fill all mandatory fields.</span>
      <br/>
      <br/>
    <?php } ?>
    <form action="<?php echo $action; ?>" method="post" name="payuForm">
      
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
     
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                     <div class="col-md-12">
                                              
        <input name="amount" placeholder="Amount" value="<?php echo (empty($posted['amount'])) ? '' : $posted['amount']; ?>" required/>
                            </div>

                            

                    <div class="heading mobInfoHead">
                        <h3 class="pos" style="text-align: center;">Enter Your Information</h3>
                        <em>( * Mandatory field )</em>
                    </div>
                </div><br>
        <div class="col-md-12">
                    <div class="information-box">       
      
                        

         <div class="row">
                            <div class="col-md-4">
     <input name="firstname" placeholder="Name*" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>" required/>
                            </div>
                            <div class="col-md-4">
                <input name="email" placeholder="Email*" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" required/>
                            </div>
                            <div class="col-md-4">
                        <input name="phone" placeholder="Mobile No.*" value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" required/>
                            </div>
                        </div>
        <tr>
        
      <td colspan="3"><input placeholder="Purpose" name="productinfo"value="Donate" readonly=""></td>
        </tr>
        <tr>
          <input type="hidden" name="surl" value="<?php echo $surl; ?>"/>        
        </tr>

        <tr>
         <input type="hidden" name="furl" value="https://www.consumer-voice.org/payumoney-failure/" />

        </tr>
    

        <tr>
          <td colspan="3"><input type="hidden" name="service_provider" value="payu_paisa" size="64" /></td>
        </tr>

       </div>
   </div>
       
        <tr>
          <?php if(!$hash) { ?>
            <td colspan="4" ><center><input type="submit" value="Submit" /></center></td>
          <?php } ?>
        </tr>
    </div>
         </form>


  </body>
</html>



<?php /**PATH E:\xampp\htdocs\demolaravel\resources\views/donatenow.blade.php ENDPATH**/ ?>