
<br>
Dear <?php echo e($donate['name']); ?>,
<br>
Thank you! We obliged to your valuable contribution.

<br>
Best Regards
<br>
Demolaravel

<?php /**PATH E:\xampp\htdocs\demolaravel\resources\views/emails/donateemails.blade.php ENDPATH**/ ?>